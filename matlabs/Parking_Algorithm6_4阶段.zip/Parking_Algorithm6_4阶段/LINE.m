function Y = LINE(xy_start,xy_stop,c)
plot([xy_start(1),xy_stop(1)],[xy_start(2),xy_stop(2)],c)
hold on
end

